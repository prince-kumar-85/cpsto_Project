import React from "react";
import AwarenessPage from "./AwarenessPage";

function App() {
  return <AwarenessPage />;
}

export default App;

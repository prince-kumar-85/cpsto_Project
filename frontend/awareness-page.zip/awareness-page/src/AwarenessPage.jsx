import React, { useState } from "react";
import "./AwarenessPage.css";

const AwarenessPage = () => {
  const facts = [
    "Washing hands with soap can reduce diarrheal diseases by up to 40%.",
    "Boiling water for just 1 minute kills most harmful germs.",
    "Using a lid on water containers prevents mosquito breeding.",
    "Unsafe food causes over 200 diseases, including typhoid and cholera.",
    "Flies can transfer germs to uncovered food within seconds."
  ];

  const [fact, setFact] = useState("");

  const showRandomFact = () => {
    const randomFact = facts[Math.floor(Math.random() * facts.length)];
    setFact(randomFact);
  };

  return (
    <div className="awareness-container">
      <h1 className="page-title">🌍 Community Awareness: Hygiene & Prevention</h1>

      {/* Awareness Cards */}
      <div className="cards">
        <div className="card fade-in">
          <img
            src="https://cdn-icons-png.flaticon.com/512/3050/3050525.png"
            alt="Handwash"
          />
          <h2>Handwashing</h2>
          <ul className="tips-list">
            <li>Wash hands for at least <b>20 seconds</b>.</li>
            <li>Use soap & clean water.</li>
            <li>Wash before meals and after using the toilet.</li>
          </ul>
        </div>

        <div className="card fade-in delay">
          <img
            src="https://cdn-icons-png.flaticon.com/512/809/809957.png"
            alt="Water"
          />
          <h2>Safe Drinking Water</h2>
          <ul className="tips-list">
            <li>Always <b>boil or filter</b> water.</li>
            <li>Store water in clean, covered containers.</li>
            <li>Avoid drinking from open or unsafe sources.</li>
          </ul>
        </div>

        <div className="card fade-in delay2">
          <img
            src="https://cdn-icons-png.flaticon.com/512/1046/1046784.png"
            alt="Food Hygiene"
          />
          <h2>Food Hygiene</h2>
          <ul className="tips-list">
            <li>Eat freshly cooked food.</li>
            <li>Keep food covered to protect from flies.</li>
            <li>Avoid street food during monsoon.</li>
          </ul>
        </div>

        <div className="card fade-in delay3">
          <img
            src="https://cdn-icons-png.flaticon.com/512/2972/2972185.png"
            alt="Sanitation"
          />
          <h2>Sanitation</h2>
          <ul className="tips-list">
            <li>Dispose of waste in bins.</li>
            <li>Keep toilets clean and dry.</li>
            <li>Avoid open defecation.</li>
          </ul>
        </div>
      </div>

      {/* Did You Know Section */}
      <section className="fact-section">
        <h2 className="fact-title">💡 Did You Know?</h2>
        <button className="fact-btn" onClick={showRandomFact}>
          Show a Fact
        </button>
        {fact && <p className="fact-box fade-in">{fact}</p>}
      </section>
    </div>
  );
};

export default AwarenessPage;
